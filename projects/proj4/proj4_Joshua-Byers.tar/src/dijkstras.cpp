//dijkstras.cpp, Joshua Byers
//Main execution of program.
#include "Gameboard.cpp"

int main() {
	Gameboard gb;
	//Read in board.
	gb.read_board();
	//Get the shortest path.
	gb.find_dijkstra_path();
}
