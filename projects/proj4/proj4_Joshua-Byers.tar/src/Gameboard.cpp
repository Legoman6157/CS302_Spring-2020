//Gameboard.cpp, Joshua Byers
//The cpp file that defines the Gameboard class member functions

#include "Gameboard.h"

//Gameboard
void Gameboard::read_board() {
	int N_pieces;

	std::stringstream ss;
	char char_buff;

	char piece_buff;
	int cost_buff;

	//Get how many pieces there are
	std::cin >> N_pieces;

	//Get list of pieces and their respective costs
	for (int i = 0; i < N_pieces; i++) {
		std::cin >> piece_buff >> cost_buff;
		piece_costs.insert(std::pair<char, int>(piece_buff, cost_buff));
	}//for (i < N_pieces)

	//Get rows and cols and set visited matrix and board matrix to that size.
	std::cin >> N_rows >> N_cols;
	board.resize(N_rows, N_cols);
	visited.resize(N_rows, N_cols);

	//Read in board to internal matrix (board)
	for (int i = 0; i < N_rows; i++) {
		for (int j = 0; j < N_cols; j++) {
			std::cin >> char_buff;
			board[i][j] = char_buff;
		}// for (j < N_cols)
	}//for (i < N_rows)

	//Get source and sink
	std::cin >> source.x >> source.y;
	std::cin >> sink.x >> sink.y;

}//Gameboard::read_board()

//A private function that gets the direction that offers the smallest cost.
direction Gameboard::get_direction(pixel loc) {

	//Determines whether a certain direction is a valid move or not.
	//I will be using the cardinal directions N, E, W, and S.
	bool N_valid = loc.x > 0,
		  E_valid = loc.y < N_cols - 1,
		  W_valid = loc.y > 0,
		  S_valid = loc.x < N_rows - 1;

	//The current smallest move.
	int current_smallest = 0;
	
	//Return value, will tell what best direction is.
	//Z just means that there is no valid direction.
	direction next_direction = Z;

	//Defines location of directions for easier reading.
	pixel N_pixel(loc.x-1, loc.y),
			E_pixel(loc.x, loc.y+1),
			W_pixel(loc.x, loc.y-1),
			S_pixel(loc.x+1, loc.y);

	//If N is a valid direction and it has't been visited.
	if (N_valid && (!visited[N_pixel.x][N_pixel.y])) {
		current_smallest = piece_costs[ board[N_pixel.x][N_pixel.y] ];
		next_direction = N;
	}

	//If E is a valid direction AND (E has not been visited AND 
	//	(the cost of E is smaller than the current smallest or the next direction hasn't been set)
	//)
	if (E_valid
		 &&
		 ((!(visited[E_pixel.x][E_pixel.y]))
			&&
			((piece_costs[ board[E_pixel.x][E_pixel.y] ] < current_smallest)
			  ||
			  (next_direction == Z)
			)
		)) {
		current_smallest = piece_costs[ board[E_pixel.x][E_pixel.y] ];
		next_direction = E;
	}

	//If W is a valid direction AND (W has not been visited AND 
	//	(the cost of W is smaller than the current smallest or the next direction hasn't been set)
	//)
	if (W_valid
		&& (
			(!visited[W_pixel.x][W_pixel.y])
			&& ( 
				(piece_costs[ board[W_pixel.x][W_pixel.y] ] < current_smallest)
				||
				(next_direction == Z)
			)
		) 
		) {
		current_smallest = piece_costs[ board[W_pixel.x][W_pixel.y] ];
		next_direction = W;
	}

	//If S is a valid direction AND (S has not been visited AND 
	//	(the cost of S is smaller than the current smallest or the next direction hasn't been set)
	//)
	if (S_valid
		&& (
			(!visited[S_pixel.x][S_pixel.y])
			&& ( 
				(piece_costs[ board[S_pixel.x][S_pixel.y] ] < current_smallest)
				||
				(next_direction == Z)
			)
		) 
		) {
		current_smallest = piece_costs[ board[S_pixel.x][S_pixel.y] ];
		next_direction = S;
	}

	//Switch-case to set which direction will actually be visited.
	switch (next_direction) {
		case N:
			visited[N_pixel.x][N_pixel.y] = true;
			break;
		case E:
			visited[E_pixel.x][E_pixel.y] = true;
			break;
		case W:
			visited[W_pixel.x][W_pixel.y] = true;
			break;
		case S:
			visited[S_pixel.x][S_pixel.y] = true;
			break;
		case Z:
			break;
	}

	return next_direction;
}//get_direction(Gameboard& gb, pixel loc)

//Finds the shortest path by finding only the smallest moves, no better path-finding strategy.
//I hadn't properly read on Dijkstra's algorithm.
std::vector<pixel> Gameboard::find_dijkstra_path() {

	//Set current pixel to the source pixel and push to "stack"
	pixel curr_pixel = source;
	d_path.push_back(curr_pixel);

	//Just the character representation of the piece of the current location.
	char curr_piece;	

	//While the stack isn't empty and we haven't found the end,
	while ((!d_path.empty()) && !(curr_pixel == sink)) {
		curr_piece = board[curr_pixel.x][curr_pixel.y];

		//Depending on which direction has the smallest cost,
		switch (get_direction(curr_pixel)) {
			case N:
				total_cost += piece_costs[curr_piece];		//Add move to total cost
				curr_pixel.x -= 1;								//Move current location
				d_path.push_back(curr_pixel);					//Push new location to "stack"
				break;
			case E:
				total_cost += piece_costs[curr_piece];
				curr_pixel.y += 1;
				d_path.push_back(curr_pixel);
				break;
			case W:
				total_cost += piece_costs[curr_piece];
				curr_pixel.y -= 1;
				d_path.push_back(curr_pixel);
				break;
			case S:
				total_cost += piece_costs[curr_piece];
				curr_pixel.x += 1;
				d_path.push_back(curr_pixel);
				break;

			//If no valid move is available,
			case Z:
			default:
				total_cost -= piece_costs[curr_piece];		//Decrement the totall cost of the path by the previous move.
				d_path.pop_back();								//Remove the pixel from the path
				curr_pixel = d_path.back();					//Set the location to the move prior to the previous.
		}//switch (get_direction(curr_pixel))

	}//while not empty and not sink

	//Print the total cost and the path.
	std::cout << total_cost << std::endl;
	for (auto it : d_path)
		std::cout << it.x << ' ' << it.y << " (" << board[it.x][it.y] << ')' << std::endl;

	return d_path;
}
